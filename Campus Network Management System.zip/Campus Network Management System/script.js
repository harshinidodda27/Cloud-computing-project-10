// Change sections
function showSection(sectionName) {

    const sections = document.querySelectorAll(".section");

    sections.forEach(function (section) {
        section.classList.add("hidden");
    });

    document.getElementById(sectionName).classList.remove("hidden");
}


// Search devices
function searchDevices() {

    const input = document.getElementById("searchInput");
    const filter = input.value.toLowerCase();

    const rows = document.querySelectorAll("#deviceTable tr");

    rows.forEach(function (row) {

        const text = row.textContent.toLowerCase();

        if (text.includes(filter)) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
}


// Open Add Device Form
function openDeviceForm() {

    document.getElementById("deviceModal").style.display = "flex";
}


// Close Add Device Form
function closeDeviceForm() {

    document.getElementById("deviceModal").style.display = "none";
}


// Add new device
function addDevice() {

    const name = document.getElementById("deviceName").value.trim();
    const type = document.getElementById("deviceType").value;
    const ip = document.getElementById("deviceIP").value.trim();
    const location = document.getElementById("deviceLocation").value.trim();
    const status = document.getElementById("deviceStatus").value;

    if (name === "" || ip === "" || location === "") {

        alert("Please fill all fields");
        return;
    }

    const table = document.getElementById("deviceTable");

    const row = document.createElement("tr");

    let statusClass = "";

    if (status === "Online") {
        statusClass = "online-status";
    } else {
        statusClass = "offline-status";
    }

    row.innerHTML = `
        <td>${name}</td>
        <td>${type}</td>
        <td>${ip}</td>
        <td>${location}</td>
        <td>
            <span class="status ${statusClass}">
                ${status}
            </span>
        </td>
        <td>
            <button onclick="removeDevice(this)">
                Delete
            </button>
        </td>
    `;

    table.appendChild(row);

    updateDeviceCount();

    document.getElementById("deviceName").value = "";
    document.getElementById("deviceIP").value = "";
    document.getElementById("deviceLocation").value = "";

    closeDeviceForm();

    alert("Device added successfully!");
}


// Delete device
function removeDevice(button) {

    if (confirm("Are you sure you want to delete this device?")) {

        button.parentElement.parentElement.remove();

        updateDeviceCount();
    }
}


// Update device statistics
function updateDeviceCount() {

    const rows = document.querySelectorAll("#deviceTable tr");

    let online = 0;
    let offline = 0;

    rows.forEach(function (row) {

        const status = row.querySelector(".status");

        if (status) {

            if (status.textContent.trim() === "Online") {
                online++;
            } else {
                offline++;
            }
        }
    });

    document.getElementById("totalDevices").textContent =
        rows.length;

    document.getElementById("onlineDevices").textContent =
        online;

    document.getElementById("offlineDevices").textContent =
        offline;
}


// Save settings
function saveSettings() {

    alert("Network settings saved successfully!");
}


// Close modal when clicking outside
window.onclick = function (event) {

    const modal = document.getElementById("deviceModal");

    if (event.target === modal) {
        modal.style.display = "none";
    }
};